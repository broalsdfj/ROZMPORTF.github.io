// Mobile nav
const toggle = document.querySelector('.nav-toggle');
const links = document.querySelector('.nav-links');
if (toggle) {
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('show');
    toggle.setAttribute('aria-expanded', String(open));
  });
}

// Smooth scroll (implicit via anchor behavior in modern browsers)

// Lightbox
const lightboxStyle = document.createElement('style');
lightboxStyle.textContent = `
  .lb-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.75);display:none;align-items:center;justify-content:center;padding:2rem;z-index:50}
  .lb-backdrop.show{display:flex}
  .lb-content{max-width:min(1200px,92vw);max-height:92vh}
  .lb-content img{width:100%;height:auto;border-radius:12px;box-shadow:0 30px 60px rgba(0,0,0,.35)}
  .lb-close{position:fixed;top:16px;right:16px;background:#fff;border:none;border-radius:999px;padding:.5rem .75rem;font-weight:800;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer}
`;
document.head.appendChild(lightboxStyle);

const backdrop = document.createElement('div');
backdrop.className = 'lb-backdrop';
backdrop.innerHTML = '<button class="lb-close" aria-label="Close image">×</button><div class="lb-content"></div>';
document.body.appendChild(backdrop);

document.querySelectorAll('[data-lightbox="gallery"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const img = document.createElement('img');
    img.src = a.getAttribute('href');
    img.alt = a.querySelector('img')?.alt || 'Expanded image';
    const content = backdrop.querySelector('.lb-content');
    content.innerHTML = '';
    content.appendChild(img);
    backdrop.classList.add('show');
  });
});

backdrop.addEventListener('click', e => {
  if (e.target.classList.contains('lb-backdrop') || e.target.classList.contains('lb-close')) {
    backdrop.classList.remove('show');
  }
});

// Year
document.getElementById('year').textContent = new Date().getFullYear();
